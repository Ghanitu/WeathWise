import React from "react";

const Preferences = () => (
  <div className="settings-section">
    <h2>Preferences</h2>
    <p>Customize your app experience.</p>
  </div>
);

export default Preferences;
